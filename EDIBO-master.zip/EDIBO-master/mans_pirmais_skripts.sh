#!/bin/bash

mkdir ABC
cd ABC
touch a.txt
mkdir ../DEF
cp ./a.txt ../DEF/b.txt
